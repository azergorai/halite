#!/bin/bash
python3.6 -m pip install --target . tqdm
python3.6 -m pip install --target . zstd
